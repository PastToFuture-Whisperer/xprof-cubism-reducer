#!/bin/bash
# Copyright (c) 2026 YourNameOrHandle
# SPDX-License-Identifier: MIT
#
# This script is part of the open-source trace log reduction tool.
set -e

# =====================================================================
# [SPECIFICATION] 1st Argument: RESOLUTION (%) / Default: 100.0 if omitted
# Usage Examples:
#   1) ./run.sh 75 sample.py --batch 64
#   2) ./run.sh sample.py --batch 64          (※ No numeric arg -> Auto-completes to RESOLUTION=100.0)
#   3) ./run.sh 50 sample.py --logdir=/tmp/logs (※ Automatic tracking & detection of custom logdir)
# =====================================================================

# Strictly reject if no arguments are provided
if [ "$#" -lt 1 ]; then
    echo " CRITICAL ERROR: Missing target script."
    echo "    Usage: $0 [RESOLUTION_%] <TARGET_SCRIPT.py> [OPTIONAL_ARGS...]"
    echo "    Example: $0 75 sample.py --batch 64"
    echo "    Example: $0 sample.py --batch 64 (Defaults to 100% resolution)"
    exit 1
fi

TARGET_LOGDIR="./logdir"

# Determine whether the 1st argument is numeric (integer or float) via regex
REGEX_NUMBER='^[0-9]+([.][0-9]+)?$'

if [[ $1 =~ $REGEX_NUMBER ]]; then
    # If 1st argument is numeric: Extract as mosaic resolution, treat 2nd+ arguments as script & options
    RESOLUTION=$1
    TARGET_SCRIPT=$2
    SCRIPT_ARGS=("${@:3}")
else
    # If 1st argument is non-numeric: Apply default resolution 100.0, treat 1st argument as script
    RESOLUTION=100.0
    TARGET_SCRIPT=$1
    SCRIPT_ARGS=("${@:2}")
fi

if [ -z "${TARGET_SCRIPT}" ] || [ ! -f "${TARGET_SCRIPT}" ]; then
    echo " CRITICAL ERROR: Target script '${TARGET_SCRIPT}' not found or specified."
    exit 1
fi

# =====================================================================
# Argument Parsing: Automatic detection & path override analysis of --logdir in SCRIPT_ARGS
# Handles both '=' separated (--logdir=/path) and space separated (--logdir /path)
# =====================================================================
HAS_LOGDIR=false
for (( i=0; i<${#SCRIPT_ARGS[@]}; i++ )); do
    arg="${SCRIPT_ARGS[$i]}"
    if [[ "$arg" == --logdir=* ]]; then
        HAS_LOGDIR=true
        TARGET_LOGDIR="${arg#*=}"
        break
    elif [[ "$arg" == "--logdir" ]]; then
        HAS_LOGDIR=true
        next_idx=$((i+1))
        if [ $next_idx -lt ${#SCRIPT_ARGS[@]} ]; then
            TARGET_LOGDIR="${SCRIPT_ARGS[$next_idx]}"
        fi
        break
    fi
done

echo "=== [UNIVERSAL PIPELINE] Running JAX Spatial Allocation Benchmark ==="
echo "  Executing Target Script : ${TARGET_SCRIPT}"
echo "  Target Logdir           : ${TARGET_LOGDIR}"
echo "  Passed Script Args      : ${SCRIPT_ARGS[*]}"
echo "  Configured Resolution   : ${RESOLUTION}%"
echo "------------------------------------------------------------------"

# =====================================================================
# [PHASE 1] Native Execution of Target Script (Safe Propagation via Quoted Array Expansion)
# =====================================================================
echo -e "\n[PHASE 1] Launching target script with its native arguments..."

if [ "$HAS_LOGDIR" = true ]; then
    # If user explicitly specifies custom --logdir, execute as-is without duplicating flags
    python3 "${TARGET_SCRIPT}" "${SCRIPT_ARGS[@]}"
else
    # If omitted, append default TARGET_LOGDIR="./logdir" and execute
    python3 "${TARGET_SCRIPT}" "${SCRIPT_ARGS[@]}" --logdir="${TARGET_LOGDIR}"
fi

echo "  JAX Process finished. Native container successfully released to OS."

# =====================================================================
# [PHASE 2] Detached Injector: Full Binary Structural Replacement
# Execute log reduction script targeting the auto-extracted TARGET_LOGDIR
# =====================================================================
if [ -d "${TARGET_LOGDIR}" ]; then
    python3 tb_log_reducer.py --logdir="${TARGET_LOGDIR}" --resolution="${RESOLUTION}"
else
    echo "  Error: Target Logdir '${TARGET_LOGDIR}' was not generated properly."
    exit 1
fi

echo -e "\n=== [PROCESS COMPLETE] All execution phases executed successfully. ==="